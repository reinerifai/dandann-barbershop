import express from "express";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Feedback storage file
const FEEDBACK_FILE = path.resolve(__dirname, "feedback.json");

// Ensure feedback file exists
if (!fs.existsSync(FEEDBACK_FILE)) {
  fs.writeFileSync(FEEDBACK_FILE, JSON.stringify([]));
}

async function startServer() {
  const app = express();
  const server = createServer(app);

  app.use(express.json());

  // API to save feedback
  app.post("/api/feedback", (req, res) => {
    try {
      const { name, email, service, rating, feedback } = req.body;
      
      if (!name || !email || !service || !rating || !feedback) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const newFeedback = {
        id: Date.now(),
        name,
        email,
        service,
        rating,
        feedback,
        createdAt: new Date().toISOString()
      };

      const data = JSON.parse(fs.readFileSync(FEEDBACK_FILE, "utf-8"));
      data.push(newFeedback);
      fs.writeFileSync(FEEDBACK_FILE, JSON.stringify(data, null, 2));

      res.status(201).json({ success: true, feedback: newFeedback });
    } catch (error) {
      console.error("Error saving feedback:", error);
      res.status(500).json({ error: "Failed to save feedback" });
    }
  });

  // API to get feedback
  app.get("/api/feedback", (req, res) => {
    try {
      const data = JSON.parse(fs.readFileSync(FEEDBACK_FILE, "utf-8"));
      res.json(data);
    } catch (error) {
      console.error("Error reading feedback:", error);
      res.status(500).json({ error: "Failed to read feedback" });
    }
  });

  // Serve static files from dist/public in production
  const staticPath =
    process.env.NODE_ENV === "production"
      ? path.resolve(__dirname, "public")
      : path.resolve(__dirname, "..", "dist", "public");

  app.use(express.static(staticPath));

  // Handle client-side routing - serve index.html for all routes
  app.get("*", (_req, res) => {
    res.sendFile(path.join(staticPath, "index.html"));
  });

  const port = process.env.PORT || 3000;

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
